<div class="row">
<div class="col-lg-3 col-6">
	<div class="col">
	  <div class="card shadow-sm bg-primary">
	    <img src="https://www.scc.sc.gov.br/images/noticias/antigas/delivery.png">
	    <div class="card-body text-white">
	      <p class="card-text text-center"> <h1> <?=$provider[0]['TOTAL'];?> </h1> </p>
	      <div class="d-flex justify-content-between align-items-center text-white">
	        <div class="btn-group ">
	          <a href="?op=list_providers" class="btn btn-sm btn-outline-secondary text-white">Lista</a>
	          <a href="?op=add_provider" class="btn btn-sm btn-outline-secondary text-white">Add</a>
	        </div>
	        <small class="text-muted">9 mins</small>
	      </div>
	    </div>
	  </div>
	</div>
</div>

<div class="col-lg-3 col-6">
	<div class="col">
	  <div class="card shadow-sm bg-primary">
	    <img src="https://www.scc.sc.gov.br/images/noticias/antigas/delivery.png">
	    <div class="card-body text-white">
	      <p class="card-text text-center"><h1> <?=$products[0]['TOTAL'];?> </h1></p>
	      <div class="d-flex justify-content-between align-items-center">
	        <div class="btn-group">
	          <a href="?op=list_products" class="btn btn-sm btn-outline-secondary text-white">Lista</a>
	          <a href="?op=add_product" class="btn btn-sm btn-outline-secondary text-white">Add</a>
	        </div>
	        <small class="text-muted">9 mins</small>
	      </div>
	    </div>
	  </div>
	</div>
</div>
</div>